import { Routes, Route } from "react-router-dom";
import Header from "./components/Header.jsx";
import Home from "./pages/Home.jsx";
import Simulado from "./pages/Simulado.jsx";
import Resultado from "./pages/Resultado.jsx";

export default function App() {
  return (
    <>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/simulado" element={<Simulado />} />
        <Route path="/resultado" element={<Resultado />} />
      </Routes>
    </>
  );
}
