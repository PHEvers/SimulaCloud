import { useNavigate } from "react-router-dom";
import { questoes, questoesPorDominio, DOMINIOS } from "../data/questions.js";

export default function Home() {
  const navigate = useNavigate();
  const porDominio = questoesPorDominio();

  return (
    <div className="container">
      <section style={styles.hero}>
        <h1 style={styles.title}>
          Pratique até estar pronto
          <br />
          para a certificação.
        </h1>
        <p style={styles.subtitle}>
          Simulados gratuitos para o AWS Certified Cloud Practitioner
          (CLF-C02). Sem necessidade de cadastro.
        </p>
      </section>

      <section style={styles.card}>
        <div style={styles.cardHeader}>
          <h2 style={styles.cardTitle}>AWS Cloud Practitioner</h2>
          <span className="mono" style={styles.cardMeta}>
            {questoes.length} questões
          </span>
        </div>

        <div style={styles.dominioList}>
          {Object.entries(DOMINIOS).map(([chave, nome]) => (
            <div key={chave} style={styles.dominioRow}>
              <span style={styles.dominioNome}>{nome}</span>
              <span className="mono" style={styles.dominioCount}>
                {porDominio[chave] || 0}
              </span>
            </div>
          ))}
        </div>

        <button style={styles.cta} onClick={() => navigate("/simulado")}>
          Iniciar simulado
        </button>
      </section>

      <p style={styles.footnote}>
        SimulaCloud é um projeto independente, sem vínculo com a Amazon Web
        Services.
      </p>
    </div>
  );
}

const styles = {
  hero: {
    padding: "56px 0 40px"
  },
  title: {
    fontSize: "38px",
    lineHeight: 1.15,
    marginBottom: "16px"
  },
  subtitle: {
    color: "var(--text-muted)",
    fontSize: "16px",
    maxWidth: "480px"
  },
  card: {
    background: "var(--surface)",
    border: "1px solid var(--border)",
    borderRadius: "8px",
    padding: "28px"
  },
  cardHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "baseline",
    marginBottom: "20px"
  },
  cardTitle: {
    fontSize: "20px"
  },
  cardMeta: {
    fontSize: "13px",
    color: "var(--text-muted)"
  },
  dominioList: {
    display: "flex",
    flexDirection: "column",
    gap: "2px",
    marginBottom: "24px"
  },
  dominioRow: {
    display: "flex",
    justifyContent: "space-between",
    padding: "10px 0",
    borderBottom: "1px solid var(--border)",
    fontSize: "14px"
  },
  dominioNome: {
    color: "var(--text)"
  },
  dominioCount: {
    color: "var(--text-muted)"
  },
  cta: {
    width: "100%",
    background: "var(--gold)",
    color: "#241a05",
    border: "none",
    borderRadius: "6px",
    padding: "14px",
    fontSize: "15px",
    fontWeight: 600,
    cursor: "pointer"
  },
  footnote: {
    fontSize: "12px",
    color: "var(--text-muted)",
    marginTop: "32px",
    textAlign: "center"
  }
};
